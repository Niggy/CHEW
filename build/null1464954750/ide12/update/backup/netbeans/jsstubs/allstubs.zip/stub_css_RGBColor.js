var RGBColor = {
  // This is just a stub for a builtin native JavaScript object.
/**
 * This attribute is used for the blue value of the RGB
 * color.
 * @type CSSPrimitiveValue
 */
blue: undefined,
/**
 * This attribute is used for the green value of the RGB
 * color.
 * @type CSSPrimitiveValue
 */
green: undefined,
/**
 * This attribute is used for the red value of the RGB
 * color.
 * @type CSSPrimitiveValue
 */
red: undefined,
};

