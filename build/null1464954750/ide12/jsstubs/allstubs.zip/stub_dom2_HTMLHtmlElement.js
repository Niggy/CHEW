var HTMLHtmlElement = Object.extend(new HTMLElement(), {
  // This is just a stub for a builtin native JavaScript object.
/**
 * Version information about the document's DTD. See the 
 * version attribute definition in HTML 4.01. This attribute is
 * deprecated in HTML 4.01.
 * @type String
 */
version: undefined,
});

