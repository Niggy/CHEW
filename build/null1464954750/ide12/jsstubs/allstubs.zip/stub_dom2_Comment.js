var Comment = Object.extend(new CharacterData(), {
  // This is just a stub for a builtin native JavaScript object.
});

