var ImageData = {
  // This is just a stub for a builtin native JavaScript object.
/** int[] data @type int[] */
data: undefined, // COMPAT=FF2|FF3|OPERA|SAFARI2|SAFARI3|KONQ
/** @type Number */
height: undefined, // COMPAT=FF2|FF3|OPERA|SAFARI2|SAFARI3|KONQ
/** @type Number */
width: undefined, // COMPAT=FF2|FF3|OPERA|SAFARI2|SAFARI3|KONQ
};

